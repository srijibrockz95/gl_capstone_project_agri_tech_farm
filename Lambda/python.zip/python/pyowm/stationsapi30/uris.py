#!/usr/bin/env python
# -*- coding: utf-8 -*-

ROOT_STATIONS_API_URL = 'openweathermap.org/data/3.0'

# Stations
STATIONS_URI = 'stations'
NAMED_STATION_URI = 'stations/%s'

# Measurements
MEASUREMENTS_URI = 'measurements'
