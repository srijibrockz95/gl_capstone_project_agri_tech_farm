#!/usr/bin/env python
# -*- coding: utf-8 -*-

ROOT_UV_API_URL = 'openweathermap.org/data/2.5'
UV_INDEX_URL = 'uvi'
UV_INDEX_FORECAST_URL = 'uvi/forecast'
UV_INDEX_HISTORY_URL = 'uvi/history'
